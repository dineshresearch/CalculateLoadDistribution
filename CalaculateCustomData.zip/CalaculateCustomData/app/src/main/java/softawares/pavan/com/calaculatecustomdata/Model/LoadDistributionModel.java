package softawares.pavan.com.calaculatecustomdata.Model;

/**
 * Created by Hitesh_A on 2/27/2018.
 */

public class LoadDistributionModel {
}
