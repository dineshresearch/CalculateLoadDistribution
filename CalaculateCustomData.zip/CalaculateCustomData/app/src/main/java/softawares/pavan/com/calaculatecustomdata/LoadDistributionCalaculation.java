package softawares.pavan.com.calaculatecustomdata;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class LoadDistributionCalaculation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_distribution_calaculation);
    }
    public void calaculate(View v){
        EditText frontCrubWgt=(EditText)findViewById(R.id.front_crub_weight);
        EditText frontCrubWgtDist=(EditText)findViewById(R.id.front_weight_distribution);
        EditText rearCrubWgt=(EditText)findViewById(R.id.rear_crub_weight);
        EditText rearCrubWgtDist=(EditText)findViewById(R.id.rear_weight_distribution);
        EditText wheelBase=(EditText)findViewById(R.id.wheel_base);
        EditText cG=(EditText)findViewById(R.id.cg);
        EditText driverWeight=(EditText)findViewById(R.id.driver_weight);
        EditText gradient=(EditText)findViewById(R.id.gradient);
        double f=Double.parseDouble(frontCrubWgtDist.getText().toString())*0.01*Double.parseDouble(driverWeight.getText().toString());
        double r=Double.parseDouble(rearCrubWgtDist.getText().toString())*0.01*Double.parseDouble(driverWeight.getText().toString());
        double wfs=Double.parseDouble(frontCrubWgt.getText().toString())+f;
        double wrs=Double.parseDouble(rearCrubWgt.getText().toString())+r;
        double w=wfs+wrs;
        double b=Double.parseDouble(wheelBase.getText().toString())*(wrs/w);
        double c=Double.parseDouble(wheelBase.getText().toString())*(wfs/w);
        double ca=Math.cos(Double.parseDouble(gradient.getText().toString())*(3.14/180));
        double sa=Math.sin(Double.parseDouble(gradient.getText().toString())*(3.14/180));
        double frontLoad=((w*c*ca)-((w*Double.parseDouble(cG.getText().toString()))*(0.186+sa)))/(Double.parseDouble(wheelBase.getText().toString()));
        double rearLoad=((w*b*ca)+((w*Double.parseDouble(cG.getText().toString()))*(0.186+sa)))/(Double.parseDouble(wheelBase.getText().toString()));
        TextView frontLoadextView=(TextView) findViewById(R.id.front_load);
        frontLoadextView.setText("Front load distribution : "+frontLoad);
        TextView rearLoadextView=(TextView) findViewById(R.id.rear_load);
        rearLoadextView.setText("Rear load distribution : "+rearLoad);
    }
}
